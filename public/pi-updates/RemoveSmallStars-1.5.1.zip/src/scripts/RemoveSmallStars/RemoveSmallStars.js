// ****************************************************************************
// RemoveSmallStars.js - PixInsight (PJSR) script
//
// Copyright (c) 2026 Carl Baker. All rights reserved.
//
// LICENSE
// Permission is granted, free of charge, to use, copy, modify and distribute
// this script, in whole or in part, subject to these conditions:
//
//   1. Attribution. Any copy, modified version, or software that includes any
//      part of this script must keep this copyright notice and license, and
//      must credit "Carl Baker" as the original author in its documentation
//      or about/credits information.
//
//   2. No paid or subscription use. This script, in whole or in part
//      (including modified versions and derived code), may not be included in,
//      bundled with, or distributed as part of any software, script, plugin,
//      module, service or package that is sold, licensed for a fee, or
//      offered under a subscription or other paid-access model.
//
//   3. Free redistribution only. Any distribution must be free of charge and
//      under these same terms.
//
// Using this script to process your own images, including images you sell,
// is permitted. For any use not covered here, contact the author for
// written permission.
//
// THIS SCRIPT IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY CLAIM, DAMAGES OR
// OTHER LIABILITY ARISING FROM THE USE OF THIS SCRIPT.
// ----------------------------------------------------------------------------
//
// Removes small stars from a (stretched) image while leaving larger stars
// untouched, with a live, zoomable preview inside the dialog.
//
// Port of remove_small_stars.py. Same method:
//   1. Smooth background estimated on a 24 px grid (median of a 48 px window,
//      3x3 median-smoothed, bilinear interpolated).
//   2. Stars detected on luminance (image - background), lightly smoothed,
//      thresholded at N x robust noise sigma; 8-connected blobs = stars.
//   3. Star size = equivalent diameter 2*sqrt(area/pi) in pixels.
//   4. Stars below the cutoff are replaced by the local background, with grow,
//      outward feather and optional matching grain. Pixels of larger stars are
//      always protected.
//
// Optional starless image (e.g. from StarXTerminator / StarNet):
//   - Target = stars-only image: used as is.
//   - Target = full image: stars are extracted with unscreen
//     stars = 1 - (1 - target) / (1 - starless).
//   The preview can show starless + reduced stars (screen or add), and Apply
//   then creates both the reduced stars-only image and the combined image.
//
// Apply always creates NEW image windows; the source images are not modified.
// ****************************************************************************

#feature-id    RemoveSmallStars : Utilities > RemoveSmallStars
#feature-info  Removes stars smaller than a chosen pixel diameter, with live preview, optional starless recombination and optional removed-star mask.

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/DataType.jsh>

#define RSS_TITLE   "Remove Small Stars"
#define RSS_VERSION "1.5.1"
#define RSS_SETTINGS_KEY "RemoveSmallStars"

// ===== CORE BEGIN (pure JavaScript, no PJSR dependencies) =====

var RSS_DEFAULTS = { diameter: 4.0, threshold: 5.0, grow: 1.5, feather: 1.0, grain: 0.8, faint: 1.0 };

// k-th smallest of a[0..n-1] (in place, Hoare selection)
function RSS_select(a, n, k) {
   var lo = 0, hi = n - 1;
   while (hi > lo) {
      var pivot = a[(lo + hi) >> 1], i = lo, j = hi;
      while (i <= j) {
         while (a[i] < pivot) i++;
         while (a[j] > pivot) j--;
         if (i <= j) { var t = a[i]; a[i] = a[j]; a[j] = t; i++; j--; }
      }
      if (k <= j) hi = j; else if (k >= i) lo = i; else break;
   }
   return a[k];
}

function RSS_medianSigma(a, n) {
   if (n < 1) return { median: 0, sigma: 0 };
   var med = RSS_select(a, n, n >> 1);
   for (var i = 0; i < n; i++) a[i] = Math.abs(a[i] - med);
   var mad = RSS_select(a, n, n >> 1);
   return { median: med, sigma: 1.4826 * mad };
}

// Deterministic gaussian noise: 64K-entry table, hashed by pixel position
// (same value for a pixel in draft and final renders).
var RSS_NOISE = (function () {
   var t = new Float32Array(65536), seed = 12345;
   function rnd() { seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
   for (var i = 0; i < 65536; i += 2) {
      var u = Math.max(rnd(), 1e-12), v = rnd(), r = Math.sqrt(-2 * Math.log(u));
      t[i] = r * Math.cos(2 * Math.PI * v);
      t[i + 1] = r * Math.sin(2 * Math.PI * v);
   }
   return t;
})();

function RSS_noise(x, y) {
   return RSS_NOISE[(x * 1103 + y * 2689 + (x >> 8) * 31337 + (y >> 8) * 7919) & 65535];
}

function RSS_combine(starless, stars, mode) {
   return (mode == 1) ? Math.min(1.0, starless + stars)
                      : 1.0 - (1.0 - starless) * (1.0 - stars);
}

// chans: array of Float32Array (1 or 3), values 0..1
function RSS_Model(w, h, chans) {
   this.w = w;
   this.h = h;
   this.ch = chans;
   this.nc = chans.length;
   this.starless = null;        // optional array of Float32Array
   this.combineMode = 0;        // 0 = screen, 1 = add
   this.G = 24;
   this.labels = null;
   this.nStars = 0;
   this.diam = null;
   this.sel = null;
   this.nSel = 0;
   this.chanSigma = [];
}

RSS_Model.prototype.computeBackground = function () {
   var G = this.G, R = 24, w = this.w, h = this.h;
   var gw = this.gw = Math.floor((w - 1) / G) + 2;
   var gh = this.gh = Math.floor((h - 1) / G) + 2;
   var side = R + 1;                              // samples per axis (step 2)
   var buf = new Float32Array(side * side + 4);
   var nine = new Float32Array(9);
   this.bg = [];
   for (var c = 0; c < this.nc; c++) {
      var data = this.ch[c];
      var grid = new Float32Array(gw * gh);
      for (var gy = 0; gy < gh; gy++) {
         var cy = Math.min(gy * G, h - 1);
         var ya = Math.max(0, cy - R), yb = Math.min(h - 1, cy + R);
         for (var gx = 0; gx < gw; gx++) {
            var cx = Math.min(gx * G, w - 1);
            var xa = Math.max(0, cx - R), xb = Math.min(w - 1, cx + R);
            var n = 0;
            for (var y = ya; y <= yb; y += 2) {
               var row = y * w;
               for (var x = xa; x <= xb; x += 2) buf[n++] = data[row + x];
            }
            grid[gy * gw + gx] = RSS_select(buf, n, n >> 1);
         }
      }
      // 3x3 median smoothing of the grid (suppresses cells dominated by big stars)
      var sm = new Float32Array(gw * gh);
      for (var gy2 = 0; gy2 < gh; gy2++)
         for (var gx2 = 0; gx2 < gw; gx2++) {
            var m = 0;
            for (var dy = -1; dy <= 1; dy++) {
               var yy = Math.min(gh - 1, Math.max(0, gy2 + dy));
               for (var dx = -1; dx <= 1; dx++) {
                  var xx = Math.min(gw - 1, Math.max(0, gx2 + dx));
                  nine[m++] = grid[yy * gw + xx];
               }
            }
            sm[gy2 * gw + gx2] = RSS_select(nine, 9, 4);
         }
      this.bg.push(sm);
   }
};

// Background of channel c for n pixels of row y starting at x0 with step.
RSS_Model.prototype.bgRow = function (c, y, x0, step, n, out) {
   var G = this.G, gw = this.gw, grid = this.bg[c];
   var fy = y / G, j = Math.floor(fy);
   if (j > this.gh - 2) j = this.gh - 2;
   var ty = fy - j;
   var r0 = j * gw, r1 = r0 + gw;
   var rg = this.rowBuf;
   if (!rg || rg.length < gw) rg = this.rowBuf = new Float32Array(gw);
   for (var q = 0; q < gw; q++) rg[q] = grid[r0 + q] + (grid[r1 + q] - grid[r0 + q]) * ty;
   var invG = 1.0 / G, kmax = gw - 2, x = x0;
   for (var i = 0; i < n; i++, x += step) {
      var fx = x * invG, k = fx | 0;
      if (k > kmax) k = kmax;
      out[i] = rg[k] + (rg[k + 1] - rg[k]) * (fx - k);
   }
};

RSS_Model.prototype.detect = function (threshold) {
   var w = this.w, h = this.h, N = w * h, nc = this.nc, x, y, i, c;
   this.threshold = threshold;
   var lum = new Float32Array(N);
   var row = new Float32Array(w);
   for (y = 0; y < h; y++)
      for (c = 0; c < nc; c++) {
         this.bgRow(c, y, 0, 1, w, row);
         var d = this.ch[c], o = y * w;
         for (x = 0; x < w; x++) lum[o + x] += (d[o + x] - row[x]) / nc;
      }

   // separable gaussian, sigma = 1 px
   var k0 = 0.4026, k1 = 0.2442, k2 = 0.0545;
   var tmp = new Float32Array(N);
   for (y = 0; y < h; y++) {
      var o2 = y * w;
      for (x = 0; x < w; x++) {
         var xm1 = x > 0 ? x - 1 : 0, xm2 = x > 1 ? x - 2 : 0;
         var xp1 = x < w - 1 ? x + 1 : w - 1, xp2 = x < w - 2 ? x + 2 : w - 1;
         tmp[o2 + x] = k0 * lum[o2 + x] + k1 * (lum[o2 + xm1] + lum[o2 + xp1]) +
                       k2 * (lum[o2 + xm2] + lum[o2 + xp2]);
      }
   }
   for (y = 0; y < h; y++) {
      var ym1 = (y > 0 ? y - 1 : 0) * w, ym2 = (y > 1 ? y - 2 : 0) * w;
      var yp1 = (y < h - 1 ? y + 1 : h - 1) * w, yp2 = (y < h - 2 ? y + 2 : h - 1) * w;
      var o3 = y * w;
      for (x = 0; x < w; x++)
         lum[o3 + x] = k0 * tmp[o3 + x] + k1 * (tmp[ym1 + x] + tmp[yp1 + x]) +
                       k2 * (tmp[ym2 + x] + tmp[yp2 + x]);
   }
   tmp = null;

   // robust noise level
   var ns = Math.floor(N / 7), samp = new Float32Array(ns);
   for (i = 0; i < ns; i++) samp[i] = lum[i * 7];
   var st = RSS_medianSigma(samp, ns);
   samp = null;
   var sig = Math.max(st.sigma, 2.0e-4);   // floor: stars-only images have ~zero noise
   var thr = st.median + threshold * sig;

   // two-pass 8-connected labelling with union-find
   var labels = new Int32Array(N);
   var parent = new Int32Array(65536), next = 1;
   function find(a) {
      while (parent[a] != a) { parent[a] = parent[parent[a]]; a = parent[a]; }
      return a;
   }
   function union(a, b) {
      a = find(a); b = find(b);
      if (a < b) parent[b] = a; else if (b < a) parent[a] = b;
   }
   for (y = 0; y < h; y++) {
      var o4 = y * w, up = o4 - w;
      for (x = 0; x < w; x++) {
         var p = o4 + x;
         if (lum[p] <= thr) continue;
         var m = 0, l;
         if (x > 0 && (l = labels[p - 1]) > 0) m = l;
         if (y > 0) {
            if (x > 0 && (l = labels[up + x - 1]) > 0) { if (m == 0) m = l; else if (l != m) union(m, l); }
            if ((l = labels[up + x]) > 0) { if (m == 0) m = l; else if (l != m) union(m, l); }
            if (x < w - 1 && (l = labels[up + x + 1]) > 0) { if (m == 0) m = l; else if (l != m) union(m, l); }
         }
         if (m == 0) {
            if (next >= parent.length) {
               var np = new Int32Array(parent.length * 2);
               np.set(parent);
               parent = np;
            }
            parent[next] = next;
            m = next++;
         }
         labels[p] = m;
      }
   }
   lum = null;
   var remap = new Int32Array(next), count = 0;
   for (l = 1; l < next; l++) {
      var r = find(l);
      remap[l] = (r == l) ? ++count : remap[r];
   }
   var area = new Float64Array(count + 1);
   for (i = 0; i < N; i++) {
      var lb = labels[i];
      if (lb > 0) { lb = remap[lb]; labels[i] = lb; area[lb]++; }
   }
   this.labels = labels;
   this.nStars = count;
   this.diam = new Float32Array(count + 1);
   this.diam[0] = 1.0e30;
   for (l = 1; l <= count; l++) this.diam[l] = 2.0 * Math.sqrt(area[l] / Math.PI);

   // sky noise per channel (for grain)
   this.chanSigma = [];
   var cap = Math.ceil(h / 7) * Math.ceil(w / 3) + 8, sb = new Float32Array(cap);
   for (c = 0; c < nc; c++) {
      var n = 0, dc = this.ch[c];
      for (y = 0; y < h; y += 7) {
         this.bgRow(c, y, 0, 1, w, row);
         for (x = 0; x < w; x += 3)
            if (labels[y * w + x] == 0) sb[n++] = dc[y * w + x] - row[x];
      }
      this.chanSigma.push(RSS_medianSigma(sb, n).sigma);
   }
   this.buildNearest();
   if (this.cutoff !== undefined) this.setCutoff(this.cutoff);
};

// Nearest-star feature transform, computed once per detection.
// near[i] = label of the closest star pixel (0 = none within ~32 px)
// dist[i] = distance to it in 1/8 px (chamfer 8/11), 255 = too far.
// Every slider except the threshold then only needs table look-ups.
RSS_Model.prototype.buildNearest = function () {
   var w = this.w, h = this.h, N = w * h, near = this.labels, x, y, k, q, b, l;
   var dist = new Uint8Array(N);
   for (k = 0; k < N; k++) dist[k] = near[k] > 0 ? 0 : 255;
   for (y = 0; y < h; y++)
      for (x = 0, k = y * w; x < w; x++, k++) {
         b = dist[k];
         if (b == 0) continue;
         l = near[k];
         if (x > 0 && (q = dist[k - 1] + 8) < b) { b = q; l = near[k - 1]; }
         if (y > 0) {
            var u = k - w;
            if ((q = dist[u] + 8) < b) { b = q; l = near[u]; }
            if (x > 0 && (q = dist[u - 1] + 11) < b) { b = q; l = near[u - 1]; }
            if (x < w - 1 && (q = dist[u + 1] + 11) < b) { b = q; l = near[u + 1]; }
         }
         dist[k] = b; near[k] = l;
      }
   for (y = h - 1; y >= 0; y--)
      for (x = w - 1, k = y * w + w - 1; x >= 0; x--, k--) {
         b = dist[k];
         if (b == 0) continue;
         l = near[k];
         if (x < w - 1 && (q = dist[k + 1] + 8) < b) { b = q; l = near[k + 1]; }
         if (y < h - 1) {
            var dn = k + w;
            if ((q = dist[dn] + 8) < b) { b = q; l = near[dn]; }
            if (x < w - 1 && (q = dist[dn + 1] + 11) < b) { b = q; l = near[dn + 1]; }
            if (x > 0 && (q = dist[dn - 1] + 11) < b) { b = q; l = near[dn - 1]; }
         }
         dist[k] = b; near[k] = (b >= 255) ? 0 : l;
      }
   this.near = near;     // replaces the label image (same buffer)
   this.dist = dist;
   this.labels = null;
};

RSS_Model.prototype.setCutoff = function (cutoff) {
   this.cutoff = cutoff;
   var n = this.nStars, sel = new Uint8Array(n + 1), cnt = 0;
   for (var l = 1; l <= n; l++)
      if (this.diam[l] < cutoff) { sel[l] = 1; cnt++; }
   this.sel = sel;
   this.nSel = cnt;
};

// Diameters of all detected stars (for the histogram)
RSS_Model.prototype.sizes = function () {
   return this.diam.subarray(1);
};

// distance (px) -> weight: 1 inside 'inner', smooth fade to 0 over 'fade'
function RSS_weight(dd, inner, fade) {
   if (dd <= inner + 1.0e-6) return 1.0;
   if (fade <= 0) return 0.0;
   var t = (dd - inner) / fade;
   return t < 1.0 ? 1.0 - t * t * (3.0 - 2.0 * t) : 0.0;
}

// Process region [x0,x1) x [y0,y1) sampled with 'step'.
// p = { grow, feather, grain, faint, original, withStarless }
//   faint: 0.5..1, brightness factor for the stars that are KEPT
//          (scales their signal above the background).
// Returns { w, h, ch: [Float32Array...], alpha: Float32Array }
RSS_Model.prototype.compose = function (x0, y0, x1, y1, step, p) {
   var w = this.w;
   var rw = Math.ceil((x1 - x0) / step), rh = Math.ceil((y1 - y0) / step), n = rw * rh;
   var alpha = new Float32Array(n);          // 1 = small star replaced by background
   var keep = null;                          // weight of kept-star dimming
   var faint = (p.faint === undefined) ? 1.0 : p.faint;
   var i, j, k;

   if (!p.original) {
      var sel = this.sel, near = this.near, dist = this.dist;
      var wA = new Float32Array(256), wK = null, q;
      for (q = 0; q < 255; q++) wA[q] = RSS_weight(q / 8, p.grow, 2.0 * p.feather);
      if (faint < 0.999) {
         keep = new Float32Array(n);
         wK = new Float32Array(256);
         for (q = 0; q < 255; q++) wK[q] = RSS_weight(q / 8, p.grow + 3.0, 2.0 * p.feather + 3.0);
      }
      for (j = 0, k = 0; j < rh; j++) {
         var o = (y0 + j * step) * w + x0;
         for (i = 0; i < rw; i++, k++) {
            var idx = o + i * step, lb = near[idx];
            if (lb == 0) continue;
            if (sel[lb]) alpha[k] = wA[dist[idx]];
            else if (wK) keep[k] = wK[dist[idx]];
         }
      }
   }

   var out = [], row = new Float32Array(rw);
   var useSL = p.withStarless && this.starless;
   var dim = 1.0 - faint;
   for (var c = 0; c < this.nc; c++) {
      var src = this.ch[c], oc = new Float32Array(n);
      var g = p.grain * (this.chanSigma[c] || 0);
      var sl = useSL ? this.starless[Math.min(c, this.starless.length - 1)] : null;
      for (j = 0, k = 0; j < rh; j++) {
         var y = y0 + j * step, ro = y * w;
         var need = false;
         if (!p.original)
            for (i = 0; i < rw; i++)
               if (alpha[k + i] > 0 || (keep && keep[k + i] > 0)) { need = true; break; }
         if (need) this.bgRow(c, y, x0, step, rw, row);
         for (i = 0; i < rw; i++, k++) {
            var x = x0 + i * step, val = src[ro + x], a = alpha[k];
            if (keep && keep[k] > 0) {
               var ex = val - row[i];
               if (ex > 0) val -= dim * keep[k] * ex;
            }
            if (a > 0) {
               var fill = row[i];
               if (g > 0) fill += g * RSS_noise(x, y);
               val = val * (1.0 - a) + fill * a;
            }
            if (val < 0) val = 0; else if (val > 1) val = 1;
            if (sl) val = RSS_combine(sl[ro + x], val, this.combineMode);
            oc[k] = val;
         }
      }
      out.push(oc);
   }
   return { w: rw, h: rh, ch: out, alpha: alpha };
};


// starless (+) stars for full-resolution arrays
RSS_Model.prototype.combineFull = function (stars) {
   var out = [], N = this.w * this.h;
   for (var c = 0; c < stars.length; c++) {
      var s = stars[c], sl = this.starless[Math.min(c, this.starless.length - 1)];
      var o = new Float32Array(N);
      for (var i = 0; i < N; i++) o[i] = RSS_combine(sl[i], s[i], this.combineMode);
      out.push(o);
   }
   return out;
};

// stars = 1 - (1 - full) / (1 - starless), in place on 'full'
function RSS_unscreen(full, starless) {
   for (var c = 0; c < full.length; c++) {
      var f = full[c], s = starless[Math.min(c, starless.length - 1)], N = f.length;
      for (var i = 0; i < N; i++) {
         var den = 1.0 - s[i];
         var v = den > 1.0e-6 ? 1.0 - (1.0 - f[i]) / den : 0.0;
         f[i] = v < 0 ? 0 : (v > 1 ? 1 : v);
      }
   }
}

// ===== CORE END =====

// ---------------------------------------------------------------------------
// PixInsight helpers
// ---------------------------------------------------------------------------
function RSS_readView(view) {
   var img = view.image, w = img.width, h = img.height;
   var nc = img.numberOfChannels >= 3 ? 3 : 1;
   var chans = [];
   for (var c = 0; c < nc; c++) {
      var a = new Float32Array(w * h);
      img.getSamples(a, new Rect(0, 0, w, h), c);
      chans.push(a);
   }
   return { w: w, h: h, ch: chans };
}

function RSS_newWindow(id, w, h, chans, srcWindow) {
   var nc = chans.length;
   var win = new ImageWindow(w, h, nc, 32, true, nc >= 3, id);
   var v = win.mainView;
   v.beginProcess(UndoFlag_NoSwapFile);
   for (var c = 0; c < nc; c++)
      v.image.setSamples(chans[c], new Rect(0, 0, w, h), c);
   v.endProcess();
   if (srcWindow) {
      try { win.keywords = srcWindow.keywords; } catch (e1) {}
      try { win.copyAstrometricSolution(srcWindow); } catch (e2) {}
   }
   win.show();
   win.zoomToFit();
   return win;
}

// Float RGB arrays (display size) -> Bitmap
function RSS_toBitmap(r, g, b, w, h) {
   try {
      var img = new Image(w, h, 3, ColorSpace_RGB, 32, SampleType_Real);
      var rect = new Rect(0, 0, w, h);
      img.setSamples(r, rect, 0);
      img.setSamples(g, rect, 1);
      img.setSamples(b, rect, 2);
      var bmp = img.render();
      img.free();
      return bmp;
   } catch (e) {
      // fallback: slow but always available
      var bm = new Bitmap(w, h);
      for (var y = 0, k = 0; y < h; y++)
         for (var x = 0; x < w; x++, k++)
            bm.setPixel(x, y, 0xff000000 |
               (Math.round(r[k] * 255) << 16) | (Math.round(g[k] * 255) << 8) | Math.round(b[k] * 255));
      return bm;
   }
}

// ---------------------------------------------------------------------------
// Preview control (zoom / pan)
// ---------------------------------------------------------------------------
function RSS_PreviewControl(parent, dialog) {
   this.__base__ = Control;
   this.__base__(parent);
   this.rssDlg = dialog;
   this.bmp = null;
   this.ox = 0;
   this.oy = 0;
   this.zoom = 1;
   this.cx = 0;
   this.cy = 0;
   this.dragging = false;
   this.info = "";
   this.setMinSize(820, 620);

   this.onPaint = function () {
      var g = new Graphics(this);
      g.fillRect(this.boundsRect, new Brush(0xff141414));
      if (this.bmp) g.drawBitmap(this.ox, this.oy, this.bmp);
      else {
         g.pen = new Pen(0xff909090);
         g.drawText(20, 30, "Select a target image on the right.");
      }
      if (this.info) {
         g.pen = new Pen(0xffc0c0c0);
         g.drawText(8, 18, this.info);
      }
      g.end();
   };
   this.onResize = function () {
      if (this.rssDlg.fitMode) this.rssDlg.fit();
      else this.rssDlg.schedule();
   };
   this.onMousePress = function (x, y) {
      this.dragging = true;
      this.lx = x;
      this.ly = y;
   };
   this.onMouseMove = function (x, y) {
      if (!this.dragging || !this.rssDlg.model) return;
      this.rssDlg.fitMode = false;
      this.cx -= (x - this.lx) / this.zoom;
      this.cy -= (y - this.ly) / this.zoom;
      this.lx = x;
      this.ly = y;
      this.rssDlg.schedule();
   };
   this.onMouseRelease = function () { this.dragging = false; };
   this.onMouseWheel = function (x, y, delta) {
      var m = this.rssDlg.model;
      if (!m) return;
      var W = this.width, H = this.height;
      var ix = this.cx + (x - W / 2) / this.zoom, iy = this.cy + (y - H / 2) / this.zoom;
      var fit = Math.min(W / m.w, H / m.h);
      this.zoom = Math.min(Math.max(this.zoom * (delta > 0 ? 1.25 : 0.8), fit * 0.5), 16);
      this.rssDlg.fitMode = false;
      this.cx = ix - (x - W / 2) / this.zoom;
      this.cy = iy - (y - H / 2) / this.zoom;
      this.rssDlg.schedule();
   };
}
RSS_PreviewControl.prototype = new Control;

// Histogram of star sizes
function RSS_HistControl(parent, dialog) {
   this.__base__ = Control;
   this.__base__(parent);
   this.rssDlg = dialog;
   this.setFixedHeight(90);
   this.onPaint = function () {
      var g = new Graphics(this);
      var W = this.width, H = this.height;
      g.fillRect(this.boundsRect, new Brush(0xff1b1b1b));
      var m = this.rssDlg.model;
      if (m && m.nStars > 0) {
         var top = 40, nb = 80, counts = [], cmax = 0, b, s = m.sizes();
         for (b = 0; b < nb; b++) counts.push(0);
         for (var i = 0; i < s.length; i++) {
            var bi = Math.floor(Math.min(s[i], top - 1e-6) / top * nb);
            counts[bi]++;
         }
         for (b = 0; b < nb; b++) cmax = Math.max(cmax, Math.log(1 + counts[b]));
         var cut = m.cutoff, bw = W / nb;
         for (b = 0; b < nb; b++) {
            if (counts[b] == 0) continue;
            var hh = Math.round((H - 4) * Math.log(1 + counts[b]) / cmax);
            g.brush = new Brush(((b + 1) * top / nb <= cut) ? 0xffe05050 : 0xff8aa0c8);
            g.pen = new Pen(0x00000000);
            g.fillRect(Math.round(b * bw), H - hh, Math.round((b + 1) * bw) - 1, H);
         }
         var xc = Math.round(W * Math.min(cut, top) / top);
         g.pen = new Pen(0xffffffff);
         g.drawLine(xc, 0, xc, H);
      }
      g.end();
   };
}
RSS_HistControl.prototype = new Control;

// ---------------------------------------------------------------------------
// Dialog
// ---------------------------------------------------------------------------
function RSS_Dialog() {
   this.__base__ = Dialog;
   this.__base__();
   var self = this;

   this.model = null;
   this.targetView = null;
   this.starlessView = null;
   this.targetIsFull = false;

   this.windowTitle = RSS_TITLE + " v" + RSS_VERSION;
   this.preview = new RSS_PreviewControl(this, this);

   var LABEL_W = this.font.width("Detection threshold (sigma):") + 6;

   // Sliders: fine-grained so dragging the handle is continuous; 'click' is the
   // jump when clicking the track left/right of the handle (and arrow keys).
   var SLIDER_POSITIONS = 1000;
   function numeric(label, lo, hi, prec, click, val, tip, cb) {
      var nc = new NumericControl(self);
      nc.label.text = label;
      nc.label.minWidth = LABEL_W;
      nc.setRange(lo, hi);
      nc.slider.setRange(0, SLIDER_POSITIONS);
      var page = Math.max(1, Math.round(click / (hi - lo) * SLIDER_POSITIONS));
      try { nc.slider.pageSize = page; } catch (e1) {}
      try { nc.slider.stepSize = page; } catch (e2) {}
      nc.slider.minWidth = 160;
      nc.setPrecision(prec);
      nc.setValue(val);
      nc.toolTip = tip;
      nc.onValueUpdated = function () { cb(); };
      return nc;
   }

   // --- image selection
   this.targetLabel = new Label(this);
   this.targetLabel.text = "Stars / target image:";
   var TT_TARGET = "<p>The image to remove small stars from. It must be non-linear (stretched).</p>" +
      "<p>Either a stars-only image (e.g. the stars output of StarXTerminator or StarNet), " +
      "or a full image whose stars have not been removed.</p>" +
      "<p>If you also pick a starless image, set the mode below to say which of the two this is.</p>";
   this.targetLabel.toolTip = TT_TARGET;
   this.targetList = new ViewList(this);
   this.targetList.toolTip = TT_TARGET;
   this.targetList.getMainViews();
   this.targetList.onViewSelected = function (view) { self.setTarget(view); };

   this.modeCombo = new ComboBox(this);
   this.modeCombo.addItem("Target is a stars-only image");
   this.modeCombo.addItem("Target is a full image (unscreen with starless)");
   this.modeCombo.currentItem = 0;
   this.modeCombo.toolTip = "<p>Says what the target image is. Only used when a starless image is selected.</p>" +
      "<p><b>Stars-only:</b> the target is used as is.</p>" +
      "<p><b>Full image:</b> the stars are first separated from it using the starless image " +
      "(stars = 1 - (1 - target) / (1 - starless), the inverse of a screen blend), and the small " +
      "stars are then removed from that stars layer.</p>";
   this.modeCombo.onItemSelected = function (i) {
      self.targetIsFull = (i == 1);
      if (self.starlessView) self.reload();
   };

   this.starlessLabel = new Label(this);
   this.starlessLabel.text = "Starless image (optional):";
   var TT_STARLESS = "<p>Optional. The starless version of the same image (e.g. from StarXTerminator " +
      "or StarNet), stretched the same way and with the same dimensions as the target.</p>" +
      "<p>When selected, the preview can show the starless image recombined with the reduced stars, " +
      "and Apply creates both a reduced stars-only image and the recombined image.</p>";
   this.starlessLabel.toolTip = TT_STARLESS;
   this.starlessList = new ViewList(this);
   this.starlessList.toolTip = TT_STARLESS;
   this.starlessList.getMainViews();
   this.starlessList.onViewSelected = function (view) { self.setStarless(view); };

   this.combineCombo = new ComboBox(this);
   this.combineCombo.addItem("Recombine: Screen");
   this.combineCombo.addItem("Recombine: Add");
   this.combineCombo.currentItem = 0;
   this.combineCombo.toolTip = "<p>How the starless image and the reduced stars are put back together, " +
      "in the preview and in the combined output.</p>" +
      "<p><b>Screen:</b> 1 - (1 - starless) * (1 - stars). Bright areas can't clip. Use it when the stars " +
      "image was made with an 'unscreen' option (StarXTerminator's Unscreen stars, or this script's full-image mode).</p>" +
      "<p><b>Add:</b> starless + stars, clipped at 1. Use it when the stars image was made by plain " +
      "subtraction (original minus starless).</p>";
   this.combineCombo.onItemSelected = function (i) {
      if (self.model) { self.model.combineMode = i; self.schedule(); }
   };

   // --- parameters
   this.diamNC = numeric("Remove stars below (px):", 0.5, 40, 1, 0.5, RSS_DEFAULTS.diameter,
      "<p>The main control. Stars smaller than this diameter, in pixels, are removed; larger stars are left alone.</p>" +
      "<p>A star's diameter is that of a circle with the same area as the star's detected footprint, " +
      "so it depends on the detection threshold. The histogram below shows the sizes found.</p>",
      function () { if (self.model) { self.model.setCutoff(self.diamNC.value); self.updateCounts(); } self.schedule(); });
   this.thrNC = numeric("Detection threshold (sigma):", 1.5, 20, 1, 0.5, RSS_DEFAULTS.threshold,
      "<p>How bright a pixel must be above the local background, in multiples of the image noise, " +
      "to count as part of a star.</p>" +
      "<p>Lower values find fainter stars and make every star measure larger, so the size cutoff may need " +
      "raising. Changing it re-runs detection, so it updates after a short pause.</p>",
      function () { self.scheduleDetect(); });
   this.growNC = numeric("Grow mask (px):", 0, 8, 1, 0.5, RSS_DEFAULTS.grow,
      "<p>Expands the area replaced around each removed star by this many pixels, to catch the faint " +
      "outer glow that falls below the detection threshold.</p>" +
      "<p>Increase it if faint rings remain where stars were removed. Never reaches into stars that are kept.</p>",
      function () { self.schedule(); });
   this.featherNC = numeric("Feather (px):", 0, 4, 1, 0.5, RSS_DEFAULTS.feather,
      "<p>Width, in pixels, of a soft transition around each removed star so the patch blends into the " +
      "surrounding sky instead of having a hard edge.</p>", function () { self.schedule(); });
   this.grainNC = numeric("Grain:", 0, 2, 2, 0.05, RSS_DEFAULTS.grain,
      "<p>Adds noise to each patch, scaled to the measured sky noise of the image, so removed stars " +
      "don't leave unnaturally smooth spots.</p>" +
      "<p>1.0 matches the image's noise; 0 leaves the patches smooth.</p>", function () { self.schedule(); });
   this.faintNC = numeric("Star faintness:", 0.5, 1.0, 2, 0.05, RSS_DEFAULTS.faint,
      "<p>Dims the stars that are kept. 1.0 leaves them unchanged; 0.5 makes them half as bright.</p>" +
      "<p>Only the stars' brightness above the local background is scaled, so the sky and nebulosity " +
      "around them are unaffected.</p>", function () { self.schedule(); });

   // --- preview options
   this.withStarlessCB = new CheckBox(this);
   this.withStarlessCB.text = "Include starless in preview";
   this.withStarlessCB.enabled = false;
   this.withStarlessCB.toolTip = "<p>Shows the starless image recombined with the reduced stars in the preview, " +
      "so you can judge the final result. Available once a starless image is selected.</p>" +
      "<p>Preview only: Apply always creates both images when a starless image is selected.</p>";
   this.withStarlessCB.onCheck = function () { self.schedule(); };

   // Press-and-hold button: shows the unprocessed image while held down.
   this.showOriginal = false;
   this.originalButton = new PushButton(this);
   this.originalButton.text = "Press to see original...";
   this.originalButton.toolTip = "<p>Hold the mouse button down on this button to see the image before " +
      "any stars were removed. Release it to return to the processed preview.</p>";
   function setOriginal(on) {
      if (self.showOriginal == on) return;
      self.showOriginal = on;
      if (self.model) self.render(true);
      self.schedule();
   }
   this.originalButton.onPress = function () { setOriginal(true); };
   this.originalButton.onRelease = function () { setOriginal(false); };
   this.originalButton.onMousePress = function () { setOriginal(true); };
   this.originalButton.onMouseRelease = function () { setOriginal(false); };

   this.highlightCB = new CheckBox(this);
   this.highlightCB.text = "Highlight removed stars";
   this.highlightCB.toolTip = "<p>Tints the stars that will be removed red in the preview, so you can see " +
      "exactly which ones the current settings affect. Preview only; not applied to the output.</p>";
   this.highlightCB.onCheck = function () { self.schedule(); };

   this.fitButton = new PushButton(this);
   this.fitButton.text = "Fit";
   this.fitButton.toolTip = "<p>Fits the whole image in the preview. While fitted, the preview refits " +
      "automatically when you resize the dialog.</p><p>Mouse wheel zooms, dragging pans.</p>";
   this.fitButton.onClick = function () { self.fit(); };
   this.oneButton = new PushButton(this);
   this.oneButton.text = "1:1";
   this.oneButton.toolTip = "<p>Shows the preview at 100% (one image pixel per screen pixel), the best " +
      "zoom for judging individual stars.</p>";
   this.oneButton.onClick = function () { self.fitMode = false; self.preview.zoom = 1; self.schedule(); };

   this.hist = new RSS_HistControl(this, this);
   this.histLabel = new Label(this);
   this.histLabel.text = "Star sizes (px, 0-40) - red = removed";
   var TT_HIST = "<p>How many stars were detected at each diameter from 0 to 40 px (log scale). " +
      "Red bars are below the cutoff and will be removed; the white line is the cutoff.</p>" +
      "<p>A gap between groups of bars is usually a good place for the cutoff.</p>";
   this.hist.toolTip = TT_HIST;
   this.histLabel.toolTip = TT_HIST;

   this.countLabel = new Label(this);
   this.countLabel.text = "No image";
   this.statusLabel = new Label(this);
   this.statusLabel.text = "";
   this.statusLabel.wordWrapping = true;

   // --- outputs
   this.maskCB = new CheckBox(this);
   this.maskCB.text = "Also create removed-star mask";
   this.maskCB.checked = false;
   this.maskCB.toolTip = "<p>When applying, also creates a grayscale mask image: white where stars were " +
      "removed, fading to black at the feathered edges. Useful for further processing of those areas.</p>";

   this.applyButton = new PushButton(this);
   this.applyButton.text = "Apply (new images)";
   this.applyButton.toolTip = "<p>Processes the full image with the current settings and creates new image " +
      "windows. The source images are not changed and the dialog stays open.</p>" +
      "<p>Without a starless image: <i>&lt;target&gt;_nosmall</i>. With one: " +
      "<i>&lt;target&gt;_stars_nosmall</i> (reduced stars only) and <i>&lt;target&gt;_combined_nosmall</i> " +
      "(starless + reduced stars). Optionally <i>&lt;target&gt;_removed_mask</i>.</p>";
   this.applyButton.onClick = function () { self.apply(); };
   this.closeButton = new PushButton(this);
   this.closeButton.text = "Close";
   this.closeButton.toolTip = "<p>Closes the dialog. Its size is remembered for next time.</p>";
   this.closeButton.onClick = function () { self.ok(); };

   // --- layout
   var zoomRow = new HorizontalSizer;
   zoomRow.spacing = 6;
   zoomRow.add(this.fitButton);
   zoomRow.add(this.oneButton);
   zoomRow.addStretch();

   var btnRow = new HorizontalSizer;
   btnRow.spacing = 6;
   btnRow.addStretch();
   btnRow.add(this.applyButton);
   btnRow.add(this.closeButton);

   var right = new VerticalSizer;
   right.spacing = 6;
   right.add(this.targetLabel);
   right.add(this.targetList);
   right.add(this.starlessLabel);
   right.add(this.starlessList);
   right.add(this.modeCombo);
   right.add(this.combineCombo);
   right.addSpacing(8);
   right.add(this.diamNC);
   right.add(this.thrNC);
   right.add(this.growNC);
   right.add(this.featherNC);
   right.add(this.grainNC);
   right.add(this.faintNC);
   right.addSpacing(8);
   right.add(this.withStarlessCB);
   right.add(this.originalButton);
   right.add(this.highlightCB);
   right.add(zoomRow);
   right.addSpacing(8);
   right.add(this.hist);
   right.add(this.histLabel);
   right.add(this.countLabel);
   right.add(this.statusLabel);
   right.addStretch();
   right.add(this.maskCB);
   right.add(btnRow);

   this.sizer = new HorizontalSizer;
   this.sizer.margin = 8;
   this.sizer.spacing = 10;
   this.sizer.add(this.preview, 100);
   this.sizer.add(right);
   this.adjustToContents();
   try { this.userResizable = true; } catch (e0) {}
   this.fitMode = true;

   // restore the dialog size from the previous session
   var sz = RSS_loadSize();
   if (sz) this.resize(Math.max(sz.w, this.minWidth || 0), Math.max(sz.h, this.minHeight || 0));

   // --- timers (draft render, final render, re-detect)
   function timer(sec, fn) {
      var t = new Timer;
      t.interval = sec;
      t.periodic = false;
      t.onTimeout = fn;
      return t;
   }
   this.draftTimer = timer(0.02, function () { self.render(true); });
   this.finalTimer = timer(0.25, function () { self.render(false); });
   this.detectTimer = timer(0.6, function () { self.redetect(); });

   // No view is preselected: the active image may not be a stars image.
}
RSS_Dialog.prototype = new Dialog;

RSS_Dialog.prototype.status = function (msg) {
   this.statusLabel.text = msg;
   console.writeln("<end><cbr>" + RSS_TITLE + ": " + msg);
   processEvents();
};

RSS_Dialog.prototype.params = function (forPreview) {
   return {
      grow: this.growNC.value,
      feather: this.featherNC.value,
      grain: this.grainNC.value,
      faint: this.faintNC.value,
      original: forPreview ? this.showOriginal : false,
      withStarless: forPreview ? (this.withStarlessCB.checked && this.withStarlessCB.enabled) : false
   };
};

RSS_Dialog.prototype.setTarget = function (view) {
   this.targetView = (view && !view.isNull) ? view : null;
   this.reload();
};

RSS_Dialog.prototype.setStarless = function (view) {
   this.starlessView = (view && !view.isNull) ? view : null;
   if (this.starlessView && this.targetView && this.starlessView.id == this.targetView.id) {
      this.status("Starless image must differ from the target.");
      this.starlessView = null;
   }
   this.withStarlessCB.enabled = !!this.starlessView;
   if (this.starlessView) this.withStarlessCB.checked = true;
   this.reload();
};

RSS_Dialog.prototype.reload = function () {
   this.model = null;
   this.preview.bmp = null;
   if (!this.targetView) { this.preview.update(); return; }
   var t0 = new Date;
   try {
      this.status("Reading " + this.targetView.id + "...");
      var tv = RSS_readView(this.targetView);
      var sl = null;
      if (this.starlessView) {
         sl = RSS_readView(this.starlessView);
         if (sl.w != tv.w || sl.h != tv.h) {
            this.status("Starless image size differs from target - ignored.");
            sl = null;
            this.withStarlessCB.enabled = false;
         }
      }
      if (sl && this.targetIsFull) {
         this.status("Extracting stars (unscreen)...");
         RSS_unscreen(tv.ch, sl.ch);
      }
      var m = new RSS_Model(tv.w, tv.h, tv.ch);
      m.starless = sl ? sl.ch : null;
      m.combineMode = this.combineCombo.currentItem;
      this.status("Estimating background...");
      m.computeBackground();
      this.status("Detecting stars...");
      m.detect(this.thrNC.value);
      m.setCutoff(this.diamNC.value);
      this.model = m;
      this.status(m.w + " x " + m.h + ", " + m.nc + " channel(s), " + m.nStars +
                  " stars detected (" + ((new Date - t0) / 1000).toFixed(1) + " s)");
   } catch (e) {
      this.model = null;
      this.status("Error: " + e.toString());
      return;
   }
   this.updateCounts();
   this.fit();
};

RSS_Dialog.prototype.redetect = function () {
   if (!this.model) return;
   this.status("Detecting stars...");
   this.model.detect(this.thrNC.value);
   this.status(this.model.nStars + " stars detected at " + this.thrNC.value.toFixed(1) + " sigma");
   this.updateCounts();
   this.schedule();
};

RSS_Dialog.prototype.updateCounts = function () {
   var m = this.model;
   if (!m) return;
   this.countLabel.text = "Removing " + m.nSel + " of " + m.nStars + " detected stars";
   this.hist.update();
};

RSS_Dialog.prototype.schedule = function () {
   if (!this.model) return;
   this.gen = (this.gen || 0) + 1;      // invalidates any render in progress
   this.draftTimer.stop();
   this.finalTimer.stop();
   this.draftTimer.start();
   this.finalTimer.start();
};

RSS_Dialog.prototype.scheduleDetect = function () {
   if (!this.model) return;
   this.detectTimer.stop();
   this.detectTimer.start();
};

RSS_Dialog.prototype.fit = function () {
   this.fitMode = true;
   var m = this.model;
   if (!m) return;
   var W = Math.max(this.preview.width, 1), H = Math.max(this.preview.height, 1);
   this.preview.zoom = Math.min(W / m.w, H / m.h);
   this.preview.cx = m.w / 2;
   this.preview.cy = m.h / 2;
   this.schedule();
};

RSS_Dialog.prototype.render = function (draft) {
   var m = this.model, pv = this.preview;
   if (!m) return;
   var myGen = this.gen;
   var W = pv.width, H = pv.height, z = pv.zoom;
   var vx0 = pv.cx - W / (2 * z), vy0 = pv.cy - H / (2 * z);
   var x0 = Math.max(0, Math.floor(vx0)), y0 = Math.max(0, Math.floor(vy0));
   var x1 = Math.min(m.w, Math.ceil(vx0 + W / z)), y1 = Math.min(m.h, Math.ceil(vy0 + H / z));
   if (x1 <= x0 || y1 <= y0) { pv.bmp = null; pv.update(); return; }

   var dw = Math.max(1, Math.round((x1 - x0) * z)), dh = Math.max(1, Math.round((y1 - y0) * z));
   var nd = dw * dh, R = new Float32Array(nd), Gc = new Float32Array(nd), B = new Float32Array(nd);
   var A = new Float32Array(nd), p = this.params(true), u, v, k, r, c0, c1, c2;

   if (draft || z >= 1) {
      // nearest sampling (draft: one source sample per screen pixel)
      var step = (z < 1) ? Math.max(1, Math.floor(1 / z)) : 1;
      if (!draft && z >= 1) step = 1;
      r = m.compose(x0, y0, x1, y1, step, p);
      c0 = r.ch[0]; c1 = r.ch[r.ch.length > 1 ? 1 : 0]; c2 = r.ch[r.ch.length > 2 ? 2 : 0];
      var f = z * step;
      for (v = 0, k = 0; v < dh; v++) {
         var sj = Math.min(r.h - 1, Math.floor(v / f)) * r.w;
         for (u = 0; u < dw; u++, k++) {
            var si = sj + Math.min(r.w - 1, Math.floor(u / f));
            R[k] = c0[si]; Gc[k] = c1[si]; B[k] = c2[si]; A[k] = r.alpha[si];
         }
      }
      pv.info = Math.round(z * 100) + "%" + (step > 1 ? "  draft" : "");
   } else {
      // refined: box-average ~2x2 samples per screen pixel, built in strips;
      // gives up as soon as a slider moves again so the UI never waits on it.
      var st = Math.max(1, Math.floor(1 / (2 * z)));
      var cnt = new Float32Array(nd);
      var stripRows = 48 * st;
      for (var ys = y0; ys < y1; ys += stripRows) {
         var ye = Math.min(y1, ys + stripRows);
         r = m.compose(x0, ys, x1, ye, st, p);
         c0 = r.ch[0]; c1 = r.ch[r.ch.length > 1 ? 1 : 0]; c2 = r.ch[r.ch.length > 2 ? 2 : 0];
         for (var j = 0, s = 0; j < r.h; j++) {
            var dv = Math.min(dh - 1, Math.floor((ys - y0 + j * st) * z)) * dw;
            for (var i = 0; i < r.w; i++, s++) {
               var dk = dv + Math.min(dw - 1, Math.floor(i * st * z));
               R[dk] += c0[s]; Gc[dk] += c1[s]; B[dk] += c2[s]; A[dk] += r.alpha[s]; cnt[dk]++;
            }
         }
         processEvents();
         if (this.gen != myGen || this.model !== m) return;   // superseded
      }
      for (k = 0; k < nd; k++) {
         var q = cnt[k] > 0 ? 1 / cnt[k] : 0;
         R[k] *= q; Gc[k] *= q; B[k] *= q; A[k] *= q;
      }
      pv.info = Math.round(z * 100) + "%";
   }
   if (this.gen != myGen) return;
   if (this.highlightCB.checked && !this.showOriginal)
      for (k = 0; k < nd; k++) {
         var a = A[k] * 0.7;
         if (a > 0) {
            R[k] = R[k] * (1 - a) + a;
            Gc[k] = Gc[k] * (1 - a) + 0.1 * a;
            B[k] = B[k] * (1 - a) + 0.1 * a;
         }
      }

   pv.bmp = RSS_toBitmap(R, Gc, B, dw, dh);
   pv.ox = Math.round((x0 - vx0) * z);
   pv.oy = Math.round((y0 - vy0) * z);
   pv.info += (this.showOriginal ? "  [original]" : "") +
              (p.withStarless ? "  [+ starless]" : "");
   pv.update();
};


RSS_Dialog.prototype.apply = function () {
   var m = this.model;
   if (!m) return;
   var t0 = new Date;
   this.status("Rendering full resolution...");
   var p = this.params(false);
   var r = m.compose(0, 0, m.w, m.h, 1, p);
   var id = this.targetView.id, srcWin = this.targetView.window;

   if (m.starless) {
      RSS_newWindow(id + "_stars_nosmall", m.w, m.h, r.ch, srcWin);
      RSS_newWindow(id + "_combined_nosmall", m.w, m.h, m.combineFull(r.ch), srcWin);
   } else {
      RSS_newWindow(id + "_nosmall", m.w, m.h, r.ch, srcWin);
   }
   if (this.maskCB.checked)
      RSS_newWindow(id + "_removed_mask", m.w, m.h, [r.alpha], null);

   this.status("Created new image(s): " + m.nSel + " stars removed (< " +
               this.diamNC.value.toFixed(1) + " px), kept stars at " + this.faintNC.value.toFixed(2) + "x, in " +
               ((new Date - t0) / 1000).toFixed(1) + " s");
};

// ---------------------------------------------------------------------------
// Persisted dialog size (PixInsight Settings, survives restarts)
function RSS_loadSize() {
   try {
      var w = Settings.read(RSS_SETTINGS_KEY + "/DialogWidth", DataType_Int32);
      if (!Settings.lastReadOK) return null;
      var h = Settings.read(RSS_SETTINGS_KEY + "/DialogHeight", DataType_Int32);
      if (!Settings.lastReadOK) return null;
      if (w > 200 && h > 200) return { w: w, h: h };
   } catch (e) {}
   return null;
}

function RSS_saveSize(dlg) {
   try {
      Settings.write(RSS_SETTINGS_KEY + "/DialogWidth", DataType_Int32, dlg.width);
      Settings.write(RSS_SETTINGS_KEY + "/DialogHeight", DataType_Int32, dlg.height);
   } catch (e) {
      console.warningln(RSS_TITLE + ": could not save dialog size: " + e.toString());
   }
}

// ---------------------------------------------------------------------------
function main() {
   console.show();
   console.writeln("<b>" + RSS_TITLE + " v" + RSS_VERSION + "</b>");
   var dlg = new RSS_Dialog();
   dlg.execute();
   RSS_saveSize(dlg);     // covers Close button and the window's X
}

main();
